package com.example.phoneagent

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var goalInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var modelInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "Phone Agent"
            textSize = 22f
        }
        status = TextView(this).apply { textSize = 15f }

        keyInput = EditText(this).apply {
            hint = "Claude API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        modelInput = EditText(this).apply {
            hint = "Model"
            setText(prefs.getString("model", AssistantService.DEFAULT_MODEL))
        }
        goalInput = EditText(this).apply {
            hint = "Kya karna hai? (bolo ya likho)"
            minLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }

        root.addView(title)
        root.addView(status)
        root.addView(button("1) Accessibility service ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2) Battery: unrestricted karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(keyInput)
        root.addView(modelInput)
        root.addView(button("Save") {
            save()
            toast("Saved")
        })
        root.addView(goalInput)
        root.addView(button("Mic se bolo") { speak() })
        root.addView(button("START") { start() })
        root.addView(button("STOP") { AssistantService.instance?.stopAgent() })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (AssistantService.instance != null)
            "Accessibility service: ON" else "Accessibility service: OFF (step 1 karo)"
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun save() {
        val model = modelInput.text.toString().trim().ifEmpty { AssistantService.DEFAULT_MODEL }
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("key", keyInput.text.toString().trim())
            .putString("model", model)
            .apply()
    }

    private fun start() {
        save()
        val goal = goalInput.text.toString().trim()
        val svc = AssistantService.instance
        if (svc == null) {
            toast("Pehle Accessibility service ON karo")
            return
        }
        if (keyInput.text.isBlank()) {
            toast("API key daalo")
            return
        }
        if (goal.isEmpty()) {
            toast("Goal likho")
            return
        }
        svc.startGoal(goal)
        moveTaskToBack(true)
    }

    private fun speak() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try {
            startActivityForResult(i, 1)
        } catch (e: ActivityNotFoundException) {
            toast("Speech recognition nahi mila, likh ke do")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val r = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!r.isNullOrEmpty()) goalInput.setText(r[0])
        }
    }
}
