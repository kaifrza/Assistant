package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
        const val DEFAULT_MODEL = "claude-haiku-4-5-20251001"
        const val MAX_STEPS = 30

        private val SYSTEM_PROMPT = """
            You control an Android phone on behalf of its owner by calling exactly one tool per turn.
            Each turn you get the owner's GOAL, the ACTIONS SO FAR with their results, and the CURRENT SCREEN
            as a list of UI elements with ids like [3].
            Rules:
            - Use only ids from the CURRENT SCREEN. Ids change every turn.
            - If the needed app is not open, call open_app first.
            - Check the result of the previous action. If it failed or the screen did not change, try a different approach instead of repeating it.
            - If the element you need is not visible, scroll.
            - Call confirm before anything irreversible or costly that the owner did not explicitly ask for: payments, transfers, purchases, deleting data, posting publicly, changing important settings.
            - Never type passwords, PINs or OTPs. If one is needed, call done and tell the owner to enter it.
            - When the goal is finished or impossible, call done with a short message in the same language the owner used for the goal.
        """.trimIndent()
    }

    private val main = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var stopRequested = false
    @Volatile private var confirmAnswer: Boolean? = null
    @Volatile private var confirmLatch: CountDownLatch? = null

    private var overlay: LinearLayout? = null
    private var statusView: TextView? = null
    private var confirmRow: LinearLayout? = null

    @Volatile private var nodes: List<AccessibilityNodeInfo> = emptyList()

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        buildOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        stopRequested = true
        removeOverlay()
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- overlay (status + STOP + confirm)

    private fun buildOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE202020.toInt())
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            visibility = View.GONE
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            maxWidth = (230 * d).toInt()
            maxLines = 5
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        val yes = Button(this).apply {
            text = "Haan"
            setOnClickListener { answerConfirm(true) }
        }
        val no = Button(this).apply {
            text = "Nahi"
            setOnClickListener { answerConfirm(false) }
        }
        row.addView(yes)
        row.addView(no)
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { stopAgent() }
        }
        box.addView(tv)
        box.addView(row)
        box.addView(stop)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        wm.addView(box, lp)

        overlay = box
        statusView = tv
        confirmRow = row
    }

    private fun removeOverlay() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        overlay = null
    }

    private fun show(msg: String) {
        main.post {
            statusView?.text = msg
            overlay?.visibility = View.VISIBLE
        }
    }

    private fun hideOverlay() {
        main.post { overlay?.visibility = View.GONE }
    }

    private fun answerConfirm(yes: Boolean) {
        confirmAnswer = yes
        confirmLatch?.countDown()
    }

    // ---------------------------------------------------------------- public API

    fun startGoal(goal: String) {
        if (running) return
        running = true
        stopRequested = false
        Thread {
            try {
                runAgent(goal)
            } catch (e: Exception) {
                show("Error: ${e.message}")
            } finally {
                running = false
                main.postDelayed({ if (!running) hideOverlay() }, 8000)
            }
        }.start()
    }

    fun stopAgent() {
        stopRequested = true
        confirmAnswer = false
        confirmLatch?.countDown()
        show("Stop kiya gaya")
    }

    // ---------------------------------------------------------------- agent loop

    private fun runAgent(goal: String) {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val key = prefs.getString("key", "") ?: ""
        val model = prefs.getString("model", DEFAULT_MODEL)?.ifBlank { DEFAULT_MODEL } ?: DEFAULT_MODEL
        val history = ArrayList<String>()

        for (step in 1..MAX_STEPS) {
            if (stopRequested) {
                show("Roka gaya")
                return
            }
            show("Step $step: screen padh raha hoon...")
            val screen = readScreen()

            show("Step $step: soch raha hoon...")
            val call = try {
                callClaude(key, model, buildPrompt(goal, history, screen))
            } catch (e: Exception) {
                show("API error: ${e.message}")
                return
            }
            if (stopRequested) {
                show("Roka gaya")
                return
            }

            val name = call.first
            val args = call.second
            if (name == "done") {
                show(args.optString("message", "Ho gaya"))
                return
            }

            show("Step $step: $name")
            val result = execute(name, args)
            history.add("$step. $name $args -> $result")
            Thread.sleep(if (name == "open_app") 500L else 1200L)
        }
        show("Step limit (${MAX_STEPS}) poori ho gayi")
    }

    private fun buildPrompt(goal: String, history: List<String>, screen: String): String {
        val sb = StringBuilder()
        sb.append("GOAL: ").append(goal).append("\n\n")
        sb.append("ACTIONS SO FAR:\n")
        if (history.isEmpty()) {
            sb.append("(none)\n")
        } else {
            history.takeLast(15).forEach { sb.append(it).append("\n") }
        }
        sb.append("\nCURRENT SCREEN:\n").append(screen)
        return sb.toString()
    }

    // ---------------------------------------------------------------- reading the screen

    private fun readScreen(): String {
        val root = rootInActiveWindow
        if (root == null) {
            nodes = emptyList()
            return "(screen unreadable - it may be loading or locked; try wait)"
        }
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        sb.append("package: ").append(root.packageName).append("\n")

        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 120) return
            if (n.isVisibleToUser) {
                val text = if (n.isPassword) "[password field]" else n.text?.toString()?.take(60)
                val desc = n.contentDescription?.toString()?.take(60)
                val interesting = !text.isNullOrBlank() || !desc.isNullOrBlank() ||
                    n.isClickable || n.isEditable || n.isScrollable || n.isCheckable
                if (interesting) {
                    val id = list.size
                    list.add(n)
                    sb.append("[").append(id).append("] ")
                    sb.append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                    if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append("\"")
                    if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append("\"")
                    if (n.isClickable) sb.append(" clickable")
                    if (n.isEditable) sb.append(" editable")
                    if (n.isScrollable) sb.append(" scrollable")
                    if (n.isCheckable) sb.append(if (n.isChecked) " checked" else " unchecked")
                    sb.append("\n")
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    // ---------------------------------------------------------------- Claude API

    private fun prop(type: String, desc: String): JSONObject =
        JSONObject().put("type", type).put("description", desc)

    private fun tool(name: String, desc: String, props: JSONObject, required: List<String>): JSONObject =
        JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject()
                    .put("type", "object")
                    .put("properties", props)
                    .put("required", JSONArray(required))
            )

    private fun tools(): JSONArray = JSONArray()
        .put(tool("open_app", "Open an installed app by its name.",
            JSONObject().put("name", prop("string", "App name, e.g. WhatsApp, Chrome, Settings")), listOf("name")))
        .put(tool("tap", "Tap the UI element with this id from the current screen.",
            JSONObject().put("id", prop("integer", "Element id")), listOf("id")))
        .put(tool("type_text", "Put text into an editable element. This REPLACES the existing text in that field.",
            JSONObject()
                .put("id", prop("integer", "Id of an editable element"))
                .put("text", prop("string", "Text to enter")), listOf("id", "text")))
        .put(tool("scroll", "Scroll the screen to reveal more content.",
            JSONObject().put("direction", prop("string", "One of: down, up, left, right")), listOf("direction")))
        .put(tool("press", "Press a system button.",
            JSONObject().put("button", prop("string", "One of: back, home, recents, notifications, quick_settings")), listOf("button")))
        .put(tool("wait", "Wait for the screen to load.",
            JSONObject().put("seconds", prop("integer", "1 to 10")), listOf("seconds")))
        .put(tool("confirm", "Ask the owner yes/no before a risky or irreversible action. Returns their answer.",
            JSONObject().put("question", prop("string", "Short yes/no question in the owner's language")), listOf("question")))
        .put(tool("done", "Finish. Use when the goal is completed or cannot be completed.",
            JSONObject().put("message", prop("string", "Short result message for the owner")), listOf("message")))

    private fun callClaude(key: String, model: String, prompt: String): Pair<String, JSONObject> {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", SYSTEM_PROMPT)
            .put("tools", tools())
            .put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 90000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(200)}")

        val content = JSONObject(text).getJSONArray("content")
        for (i in 0 until content.length()) {
            val c = content.getJSONObject(i)
            if (c.optString("type") == "tool_use") {
                return Pair(c.getString("name"), c.optJSONObject("input") ?: JSONObject())
            }
        }
        throw RuntimeException("Model ne koi action nahi diya")
    }

    // ---------------------------------------------------------------- executing actions

    private fun execute(name: String, a: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(a.optString("name"))
                "tap" -> tap(a.optInt("id", -1))
                "type_text" -> typeText(a.optInt("id", -1), a.optString("text"))
                "scroll" -> scroll(a.optString("direction", "down"))
                "press" -> press(a.optString("button"))
                "wait" -> {
                    Thread.sleep(a.optInt("seconds", 2).coerceIn(1, 10) * 1000L)
                    "ok"
                }
                "confirm" -> confirm(a.optString("question"))
                else -> "unknown tool"
            }
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "app not found: $name"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "cannot launch $name"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        Thread.sleep(1500)
        return "opened ${match.loadLabel(pm)}"
    }

    private fun tap(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "invalid id $id"
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicked"
            cur = cur.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return if (gestureTap(r.centerX().toFloat(), r.centerY().toFloat())) "tapped by coordinates" else "tap failed"
    }

    private fun typeText(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "invalid id $id"
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "typed" else "type failed (not editable?)"
    }

    private fun scroll(dir: String): String {
        val target = nodes.firstOrNull { it.isScrollable }
        if (target != null) {
            val action = if (dir == "down" || dir == "right")
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (target.performAction(action)) return "scrolled"
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val ok = when (dir) {
            "down" -> swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)
            "up" -> swipe(w / 2, h * 0.3f, w / 2, h * 0.7f)
            "right" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
        }
        return if (ok) "swiped" else "scroll failed"
    }

    private fun press(button: String): String {
        val ok = when (button) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            else -> return "unknown button"
        }
        return if (ok) "ok" else "failed"
    }

    private fun confirm(question: String): String {
        val latch = CountDownLatch(1)
        confirmLatch = latch
        confirmAnswer = null
        main.post {
            statusView?.text = question
            confirmRow?.visibility = View.VISIBLE
            overlay?.visibility = View.VISIBLE
        }
        latch.await(120, TimeUnit.SECONDS)
        main.post { confirmRow?.visibility = View.GONE }
        val ans = confirmAnswer
        confirmLatch = null
        return when (ans) {
            true -> "owner said YES"
            false -> "owner said NO"
            null -> "no answer (timeout) - treat as NO"
        }
    }

    // ---------------------------------------------------------------- gestures

    private fun gestureTap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 400))
            .build()
        return dispatchGesture(g, null, null)
    }
}
