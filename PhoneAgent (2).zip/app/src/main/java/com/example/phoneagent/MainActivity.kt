package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var cmdInput: EditText

    private val helpText = """
COMMANDS (Hinglish ya English, bolo ya likho)

APPS
- youtube kholo / open whatsapp / camera chalao
- open google.com

CALL / MESSAGE
- Rahul ko call karo / call 9876543210
- whatsapp Rahul kaise ho bhai
- Rahul ko whatsapp pe aa raha hoon bhejo
- sms Rahul main late hoon

SEARCH / NAVIGATE
- google pe cricket score search karo
- youtube pe arijit songs
- navigate to Hazratganj

PHONE CONTROL
- volume badhao / volume kam / volume 50 / mute
- brightness badhao / brightness 30
- torch on / torch off
- wifi on / wifi off / bluetooth off / airplane mode on
- location on / mobile data off / auto rotate off / hotspot
- back / home / recent apps / notifications / quick settings
- screenshot / lock / power menu

SCREEN
- neeche scroll karo / upar scroll / swipe left / swipe right
- click Settings / Search pe click karo
- type hello (jo text box khula ho usme likhta hai)
- send karo (Send button dabata hai)

MEDIA
- gaana pause / play / next / pichla gaana

TIME / ALARM
- time kya hua / aaj ki date / battery kitni hai
- timer 5 minute / alarm 7:30 baje / alarm 6 am
""".trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Phone Assistant (offline commands)"
            textSize = 20f
        })
        status = TextView(this).apply { textSize = 15f }
        root.addView(status)

        root.addView(button("1) Accessibility service ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2) Battery: unrestricted karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(button("3) Permissions do (mic, contacts, call)") {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE
                ), 1
            )
        })
        root.addView(button("4) Write settings do (brightness, rotate)") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        val langBtn = Button(this)
        fun langLabel() = "Voice language: " + prefs.getString("lang", "en-IN") + " (badalne ke liye dabao)"
        langBtn.text = langLabel()
        langBtn.setOnClickListener {
            val n = if (prefs.getString("lang", "en-IN") == "en-IN") "hi-IN" else "en-IN"
            prefs.edit().putString("lang", n).apply()
            langBtn.text = langLabel()
        }
        root.addView(langBtn)

        val bubbleBtn = Button(this)
        fun bubbleLabel() = "Mic bubble: " + (if (prefs.getBoolean("bubble", true)) "ON" else "OFF") + " (dabao badalne ke liye)"
        bubbleBtn.text = bubbleLabel()
        bubbleBtn.setOnClickListener {
            prefs.edit().putBoolean("bubble", !prefs.getBoolean("bubble", true)).apply()
            AssistantService.instance?.applyBubble()
            bubbleBtn.text = bubbleLabel()
        }
        root.addView(bubbleBtn)

        cmdInput = EditText(this).apply {
            hint = "Command likho, jaise: youtube kholo"
        }
        root.addView(cmdInput)
        root.addView(button("RUN") { runTyped() })

        root.addView(TextView(this).apply {
            text = helpText
            textSize = 13f
            setPadding(0, pad, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (AssistantService.instance != null)
            "Accessibility service: ON" else "Accessibility service: OFF (step 1 karo)"
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun runTyped() {
        val cmd = cmdInput.text.toString().trim()
        val svc = AssistantService.instance
        if (svc == null) {
            Toast.makeText(this, "Pehle Accessibility service ON karo", Toast.LENGTH_SHORT).show()
            return
        }
        if (cmd.isEmpty()) return
        moveTaskToBack(true)
        Handler(Looper.getMainLooper()).postDelayed({ svc.runCommands(listOf(cmd)) }, 700)
    }
}
