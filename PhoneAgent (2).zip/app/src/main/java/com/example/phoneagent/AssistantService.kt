package com.example.phoneagent

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
    }

    private val main = Handler(Looper.getMainLooper())

    private var overlay: LinearLayout? = null
    private var statusView: TextView? = null
    private var micButton: Button? = null

    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var hideToken = 0

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        buildOverlay()
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale("en", "IN")
            }
        }
        show("Assistant ready. MIC dabao ya app se command likho")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
        tts?.shutdown()
        tts = null
        removeOverlay()
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- overlay (MIC bubble + status text)

    private fun buildOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0xEE202020.toInt())
            textSize = 12f
            maxWidth = (230 * d).toInt()
            maxLines = 5
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            visibility = View.GONE
        }
        val mic = Button(this).apply {
            text = "MIC"
            textSize = 11f
            setOnClickListener { toggleListen() }
        }
        box.addView(tv)
        box.addView(mic)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        wm.addView(box, lp)

        overlay = box
        statusView = tv
        micButton = mic
        applyBubble()
    }

    private fun removeOverlay() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        overlay = null
    }

    /** Show/hide the MIC bubble according to the saved setting. */
    fun applyBubble() {
        val on = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("bubble", true)
        main.post { micButton?.visibility = if (on) View.VISIBLE else View.GONE }
    }

    fun show(msg: String) {
        main.post {
            val tv = statusView ?: return@post
            tv.text = msg
            tv.visibility = View.VISIBLE
            val token = ++hideToken
            main.postDelayed({
                if (token == hideToken) tv.visibility = View.GONE
            }, 4500)
        }
    }

    private fun setMic(active: Boolean) {
        main.post { micButton?.text = if (active) "..." else "MIC" }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cmd")
    }

    // ---------------------------------------------------------------- commands

    /** Try each candidate text in order (speech gives several guesses); first one that matches a command runs. */
    fun runCommands(list: List<String>) {
        Thread {
            var res: Res? = null
            for (t in list) {
                res = Commands.handle(this@AssistantService, t)
                if (res != null) break
            }
            val r = res ?: Res("Samajh nahi aaya: \"" + (list.firstOrNull() ?: "") + "\"")
            show(r.msg)
            if (r.say) speak(r.msg)
        }.start()
    }

    // ---------------------------------------------------------------- voice

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            show("Bolo...")
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            listening = false
            setMic(false)
            show("Sun nahi paya, phir bolo")
        }

        override fun onResults(results: Bundle?) {
            listening = false
            setMic(false)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (list.isNullOrEmpty()) {
                show("Kuch sunai nahi diya")
                return
            }
            show("Suna: " + list[0])
            runCommands(list)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun toggleListen() {
        if (listening) {
            recognizer?.cancel()
            listening = false
            setMic(false)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            show("Mic permission do (app mein 'Permissions' button)")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("Is phone pe speech recognition nahi mila. App mein likh ke command do")
            return
        }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
        r.setRecognitionListener(listener)
        val lang = getSharedPreferences("cfg", MODE_PRIVATE).getString("lang", "en-IN") ?: "en-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        listening = true
        setMic(true)
        r.startListening(i)
    }
}
