package com.example.phoneagent

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Result of a command: message to show, and whether to also speak it. */
class Res(val msg: String, val say: Boolean = false)

/** One parsed command. s = cleaned text (original case), t = lowercase. */
class Ctx(val svc: AssistantService, val s: String) {
    val t: String = s.lowercase()
    val words: Set<String> = t.split(" ").toSet()

    fun has(vararg w: String): Boolean = w.any { it in words }
    fun hasText(vararg w: String): Boolean = w.any { t.contains(it) }

    val want: Boolean? = when {
        has("on", "chalu", "chaalu", "enable", "shuru", "activate") &&
            !has("off", "band", "bandh", "disable", "deactivate") -> true
        has("off", "band", "bandh", "disable", "deactivate") &&
            !has("on", "chalu", "chaalu", "enable", "shuru", "activate") -> false
        else -> null
    }
}

object Commands {

    private var torchOn = false
    private val IC = RegexOption.IGNORE_CASE

    private val EDGE_START = setOf(
        "hey", "hi", "ok", "okay", "assistant", "jarvis", "please", "plz", "pls",
        "bhai", "bro", "yaar", "zara", "jara", "mera", "meri", "mere", "mujhe"
    )
    private val EDGE_END = setOf("please", "plz", "pls", "bhai", "bro", "yaar", "na", "jaldi", "zara", "jara")
    private val OPEN_WORDS = setOf("kholo", "khol", "open", "launch", "chalao", "start")

    // Devanagari (Hindi voice typing) -> Latin words, token by token
    private val DEV = mapOf(
        "खोलो" to "kholo", "खोल" to "khol", "चालू" to "chalu", "चालु" to "chalu", "बंद" to "band",
        "पीछे" to "piche", "वापस" to "wapas", "कॉल" to "call", "फोन" to "phone", "वॉल्यूम" to "volume",
        "आवाज़" to "awaaz", "आवाज" to "awaaz", "बढ़ाओ" to "badhao", "बढ़ा" to "badhao", "घटाओ" to "kam",
        "कम" to "kam", "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "वाईफाई" to "wifi", "वाईफ़ाई" to "wifi", "ब्लूटूथ" to "bluetooth", "टॉर्च" to "torch",
        "नीचे" to "neeche", "ऊपर" to "upar", "स्क्रॉल" to "scroll", "होम" to "home", "बैक" to "back",
        "चलाओ" to "chalao", "गाना" to "gaana", "रोको" to "roko", "अगला" to "agla", "पिछला" to "pichla",
        "समय" to "samay", "बैटरी" to "battery", "ब्राइटनेस" to "brightness", "अलार्म" to "alarm",
        "टाइमर" to "timer", "मैसेज" to "message", "भेजो" to "bhejo", "क्लिक" to "click",
        "दबाओ" to "dabao", "लिखो" to "likho", "सर्च" to "search", "करो" to "karo", "कर" to "kar",
        "दो" to "do", "को" to "ko", "पर" to "par", "पे" to "pe", "में" to "mein", "ऑन" to "on", "ऑफ" to "off"
    )

    private val CALL1 = Regex("^(?:call|phone|dial|fone)\\s+(?:to\\s+)?(.+?)(?:\\s+(?:karo|kro|kar|lagao|laga|do|de))?$", IC)
    private val CALL2 = Regex("^(.+?)\\s+(?:ko\\s+)?(?:call|phone|fone)(?:\\s+(?:karo|kro|kar|lagao|laga|do|de))*$", IC)
    private val WA1 = Regex("^whatsapp\\s+(?:pe\\s+|par\\s+|to\\s+)?(\\S+)\\s+(?:ko\\s+)?(.+)$", IC)
    private val WA2 = Regex("^(\\S+)\\s+ko\\s+whatsapp\\s+(?:pe\\s+|par\\s+)?(?:message\\s+)?(.+?)(?:\\s+(?:bhejo|bhej do|bhej de|send karo))?$", IC)
    private val SMS1 = Regex("^(?:sms|text)\\s+(\\S+)\\s+(.+)$", IC)
    private val SMS2 = Regex("^(\\S+)\\s+ko\\s+(?:sms|text|message)\\s+(.+?)(?:\\s+(?:bhejo|bhej do|karo))?$", IC)
    private val TYPE = Regex("^(?:type|likho|likh|typing)\\s+(.+)$", IC)
    private val CLICK1 = Regex("^(?:click|tap|press|dabao|touch|select)\\s+(?:on\\s+)?(.+)$", IC)
    private val CLICK2 = Regex("^(.+?)\\s+(?:pe|par|ko)\\s+(?:click|tap|dabao|dabana|press|touch)(?:\\s+(?:karo|kro|kar|do))?$", IC)
    private val OPEN1 = Regex("^(?:open|launch|kholo|khol)\\s+(.+)$", IC)
    private val OPEN2 = Regex("^(.+?)\\s+(?:kholo|khol|kholna|khol do|khol de|chalao|chala do|chalu karo|chalu kro|open karo|open kro|open|launch karo|start karo)$", IC)
    private val YT1 = Regex("^(?:youtube|yt)\\s+(?:pe|par|mein|me|search|for)\\s+(.+?)(?:\\s+(?:search karo|search kro|dhundo|dhundho|chalao|play karo|dikhao|lagao))?$", IC)
    private val YT2 = Regex("^(.+?)\\s+(?:youtube pe|youtube par|on youtube|youtube mein)(?:\\s+(?:search karo|dhundo|dhundho|chalao|play karo|dikhao|lagao))?$", IC)
    private val G1 = Regex("^(?:google\\s+search|google\\s+pe|google\\s+par|google|search\\s+for|search)\\s+(.+?)(?:\\s+(?:search karo|search kro|karo|kro|dhundo))?$", IC)
    private val G2 = Regex("^(.+?)\\s+(?:search karo|search kro|search kar do|google karo|google kar do|dhundo|dhundho|khojo)$", IC)
    private val MAPS1 = Regex("^(?:navigate|directions|route|maps?)\\s+(?:to\\s+|for\\s+)?(.+)$", IC)
    private val MAPS2 = Regex("^(.+?)\\s+(?:ka route|ka rasta|ka direction|navigate karo|jana hai|tak ka route)$", IC)

    private val ALIAS = mapOf(
        "insta" to "instagram", "fb" to "facebook", "yt" to "youtube", "wa" to "whatsapp",
        "setting" to "settings", "gpay" to "google pay", "map" to "maps"
    )

    // ------------------------------------------------------------------ entry point

    fun handle(svc: AssistantService, raw: String): Res? {
        val s = clean(raw)
        if (s.isEmpty()) return null
        val c = Ctx(svc, s)
        return try {
            help(c) ?: info(c) ?: media(c) ?: volume(c) ?: brightness(c) ?: torch(c) ?: toggles(c)
                ?: system(c) ?: scroll(c) ?: timerAlarm(c) ?: call(c) ?: openApp(c) ?: whatsapp(c)
                ?: sms(c) ?: typeClick(c) ?: search(c) ?: photo(c) ?: fallbackApp(c)
        } catch (e: IllegalStateException) {
            Res(e.message ?: "Error")
        } catch (e: Exception) {
            Res("Error: ${e.message}")
        }
    }

    private fun clean(raw: String): String {
        val base = raw.trim().replace(Regex("[!?,;\u0964]"), " ").replace(Regex("\\s+"), " ").trim().trimEnd('.')
        val toks = base.split(" ").filter { it.isNotEmpty() }.map { DEV[it] ?: it }.toMutableList()
        while (toks.isNotEmpty() && toks.first().lowercase() in EDGE_START) toks.removeAt(0)
        while (toks.isNotEmpty() && toks.last().lowercase() in EDGE_END) toks.removeAt(toks.size - 1)
        return toks.joinToString(" ")
    }

    // ------------------------------------------------------------------ rules

    private fun help(c: Ctx): Res? =
        if (c.t == "help" || c.hasText("kya kar sakte", "commands list", "madad")) Res("App kholke 'Help' section dekho") else null

    private fun info(c: Ctx): Res? {
        if (c.has("kholo", "khol", "open")) return null
        if (c.t == "time" || c.t == "samay" || c.hasText("kitne baje", "what time", "time kya", "samay kya", "time batao")) {
            return Res("Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()), true)
        }
        if (c.t == "date" || c.hasText("aaj ki date", "aaj kya date", "today date", "what date", "tareekh", "kaun sa din", "aaj kya din")) {
            return Res("Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date()), true)
        }
        if (c.has("battery") && !c.has("saver")) {
            val bm = c.svc.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return Res("Battery $lvl%", true)
        }
        return null
    }

    private fun media(c: Ctx): Res? {
        if (c.hasText("youtube", " pe ", " par ") || c.has("kholo", "khol", "open")) return null
        val musicWord = c.has("gaana", "gana", "gaane", "song", "songs", "music", "track", "video")
        val single = c.t in setOf("pause", "play", "resume", "next", "previous", "prev")
        if (!musicWord && !single && !c.has("agla", "pichla")) return null
        val key = when {
            c.has("next", "agla", "skip") -> KeyEvent.KEYCODE_MEDIA_NEXT
            c.has("previous", "prev", "pichla", "piche") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            c.has("pause", "roko", "ruko", "ruk", "band", "stop") -> KeyEvent.KEYCODE_MEDIA_PAUSE
            c.has("play", "chalao", "chalu", "chala", "resume", "shuru") -> KeyEvent.KEYCODE_MEDIA_PLAY
            else -> return null
        }
        val am = c.svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return Res("Media command bheji")
    }

    private fun volume(c: Ctx): Res? {
        if (!c.has("volume", "awaaz", "awaz", "aawaz", "sound", "mute", "unmute")) return null
        if (c.has("kholo", "khol", "open")) return null
        val am = c.svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(st)
        val num = Regex("\\d+").find(c.t)?.value?.toIntOrNull()
        val flag = AudioManager.FLAG_SHOW_UI
        when {
            num != null -> am.setStreamVolume(st, num.coerceIn(0, 100) * max / 100, flag)
            c.has("unmute") -> am.setStreamVolume(st, max / 2, flag)
            c.has("mute", "zero") || c.want == false -> am.setStreamVolume(st, 0, flag)
            c.has("full", "max", "maximum", "puri", "poori") -> am.setStreamVolume(st, max, flag)
            c.has("badhao", "badha", "up", "zyada", "increase", "tez", "louder", "high") -> {
                repeat(2) { am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, flag) }
            }
            c.has("kam", "ghatao", "down", "decrease", "dheere", "low", "halka", "halke") -> {
                repeat(2) { am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, flag) }
            }
            else -> return Res("Volume: badhao / kam / mute / full / number (jaise volume 50) bolo")
        }
        return Res("Volume ${am.getStreamVolume(st) * 100 / max}%")
    }

    private fun brightness(c: Ctx): Res? {
        if (!c.has("brightness", "brightnes", "roshni")) return null
        if (!Settings.System.canWrite(c.svc)) return Res("Brightness ke liye app mein 'Write settings' permission do")
        val cr = c.svc.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
        val num = Regex("\\d+").find(c.t)?.value?.toIntOrNull()
        val target = (when {
            num != null -> num
            c.has("full", "max", "maximum", "puri", "poori") -> 100
            c.has("min", "minimum") -> 5
            c.has("badhao", "badha", "up", "zyada", "increase", "tez") -> cur + 20
            c.has("kam", "ghatao", "down", "decrease", "dheere", "low") -> cur - 20
            else -> return Res("Brightness abhi $cur% hai (badhao / kam / number bolo)")
        }).coerceIn(1, 100)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, target * 255 / 100)
        return Res("Brightness $target%")
    }

    private fun torch(c: Ctx): Res? {
        if (!c.hasText("torch", "flashlight", "flash light", "tourch") && !c.has("flash")) return null
        val cm = c.svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return Res("Is phone mein torch nahi mili")
        val state = c.want ?: !torchOn
        cm.setTorchMode(id, state)
        torchOn = state
        return Res(if (state) "Torch ON" else "Torch OFF")
    }

    private fun toggles(c: Ctx): Res? {
        val t = c.t
        val justOpen = c.has("kholo", "khol", "open", "settings")

        if (c.has("hotspot")) {
            try {
                c.svc.startActivity(
                    Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                c.svc.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return Res("Hotspot settings khol di, wahan se on/off karo")
        }
        if (c.has("rotate", "rotation", "autorotate")) {
            if (!Settings.System.canWrite(c.svc)) return Res("Rotate ke liye app mein 'Write settings' permission do")
            val cr = c.svc.contentResolver
            val cur = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1) == 1
            val st = c.want ?: !cur
            Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (st) 1 else 0)
            return Res("Auto-rotate " + if (st) "ON" else "OFF")
        }

        val wifi = t.contains("wifi") || t.contains("wi-fi") || t.contains("wi fi") || c.has("wlan")
        val target: Pair<String, String> = when {
            wifi -> Pair(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi")
            t.contains("bluetooth") || t.contains("blue tooth") -> Pair(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth")
            c.has("airplane", "aeroplane") || t.contains("flight mode") -> Pair(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "Airplane mode")
            c.has("location", "gps") -> Pair(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "Location")
            t.contains("mobile data") || t.contains("mobiledata") || c.has("cellular") ->
                Pair(Settings.ACTION_DATA_ROAMING_SETTINGS, "Mobile data")
            else -> return null
        }
        if (justOpen) {
            c.svc.startActivity(Intent(target.first).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Res("${target.second} settings khol di")
        }
        return toggleSwitch(c.svc, target.first, target.second, c.want)
    }

    private fun toggleSwitch(svc: AssistantService, action: String, name: String, want: Boolean?): Res {
        svc.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Thread.sleep(1800)
        val root = svc.rootInActiveWindow ?: return Res("$name: screen nahi padh paya")
        val nodes = allNodes(root)
        val sw = nodes.firstOrNull { it.isCheckable && (it.className?.toString() ?: "").contains("Switch") }
            ?: nodes.firstOrNull { it.isCheckable }
            ?: return Res("$name ka switch nahi mila, settings page khuli hai")
        val isOn = sw.isChecked
        if (want != null && want == isOn) {
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return Res("$name pehle se " + if (isOn) "ON hai" else "OFF hai")
        }
        clickNode(svc, sw)
        Thread.sleep(800)
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        return Res("$name " + if (isOn) "OFF kiya" else "ON kiya")
    }

    private fun system(c: Ctx): Res? {
        if (c.has("kholo", "khol", "open", "launch", "chalao")) return null
        val (action, label) = when {
            c.hasText("app band", "close app", "app close") || c.t == "close" ->
                Pair(AccessibilityService.GLOBAL_ACTION_HOME, "App band (home pe aa gaya)")
            c.has("back", "piche", "peeche", "wapas") && !c.has("call") ->
                Pair(AccessibilityService.GLOBAL_ACTION_BACK, "Back")
            c.has("home") -> Pair(AccessibilityService.GLOBAL_ACTION_HOME, "Home")
            c.has("recents", "multitask") || c.hasText("recent apps", "recent app") ->
                Pair(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps")
            c.has("notification", "notifications", "notif") ->
                Pair(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications")
            c.hasText("quick settings", "control center", "quick panel") ->
                Pair(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "Quick settings")
            c.has("screenshot") || c.hasText("screen shot") ->
                Pair(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Screenshot")
            c.has("lock", "lockscreen") -> Pair(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Screen lock")
            c.hasText("power menu", "power off", "shutdown", "shut down") ->
                Pair(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG, "Power menu")
            else -> return null
        }
        val ok = c.svc.performGlobalAction(action)
        return Res(if (ok) label else "$label nahi ho paya")
    }

    private fun scroll(c: Ctx): Res? {
        val explicit = c.has("scroll", "swipe", "neeche", "niche", "upar", "ooper", "oopar")
        if (!explicit && c.t !in setOf("down", "up", "left", "right")) return null
        val dir = when {
            c.has("neeche", "niche", "down") -> "down"
            c.has("upar", "ooper", "oopar", "up") -> "up"
            c.has("left", "baye", "bayen", "baayen") -> "left"
            c.has("right", "daye", "dayen", "dahine") -> "right"
            else -> "down"
        }
        val svc = c.svc
        if (dir == "down" || dir == "up") {
            val root = svc.rootInActiveWindow
            val target = if (root != null) {
                allNodes(root).filter { it.isScrollable }.maxByOrNull {
                    val r = Rect()
                    it.getBoundsInScreen(r)
                    r.width() * r.height()
                }
            } else null
            if (target != null) {
                val a = if (dir == "down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (target.performAction(a)) return Res("Scroll $dir")
            }
        }
        val dm = svc.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val ok = when (dir) {
            "down" -> swipe(svc, w / 2, h * 0.7f, w / 2, h * 0.3f)
            "up" -> swipe(svc, w / 2, h * 0.3f, w / 2, h * 0.7f)
            "left" -> swipe(svc, w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> swipe(svc, w * 0.2f, h / 2, w * 0.8f, h / 2)
        }
        return Res(if (ok) "Swipe $dir" else "Swipe nahi ho paya")
    }

    private fun timerAlarm(c: Ctx): Res? {
        if (c.has("timer")) {
            val m = Regex("(\\d+)\\s*(sec|second|seconds|min|mins|minute|minutes|minit|ghanta|ghante|hour|hours|hr)?")
                .find(c.t) ?: return Res("Timer kitne der ka? jaise: timer 5 minute")
            val n = m.groupValues[1].toInt()
            val unit = m.groupValues[2]
            val secs = when {
                unit.startsWith("sec") -> n
                unit.startsWith("gh") || unit.startsWith("hour") || unit == "hr" -> n * 3600
                else -> n * 60
            }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.svc.startActivity(i)
            return Res("Timer set: $secs second", true)
        }
        if (c.has("alarm", "alaram")) {
            if (c.want == false || c.has("cancel", "hatao", "delete")) {
                c.svc.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return Res("Alarms ki list khol di, wahan se band karo")
            }
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje|bje)?")
                .find(c.t) ?: return Res("Alarm kitne baje? jaise: alarm 7:30 baje")
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (ap != "am" && ap != "pm" && c.hasText("shaam", "raat", "dopahar", "evening", "night", "afternoon") && h < 12) h += 12
            if (h > 23 || min > 59) return Res("Alarm ka time galat hai")
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.svc.startActivity(i)
            return Res("Alarm set: %02d:%02d".format(h, min), true)
        }
        return null
    }

    private fun call(c: Ctx): Res? {
        val m = CALL1.find(c.s) ?: CALL2.find(c.s) ?: return null
        val target = m.groupValues[1].trim()
        val lt = target.lowercase()
        if (target.isEmpty() || lt in OPEN_WORDS || lt in setOf("log", "logs", "app", "history")) return null
        val num = lookup(c.svc, target)
        val granted = c.svc.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.svc.startActivity(i)
        return Res(if (granted) "Call laga raha hoon: $target" else "Dialer khol diya: $target")
    }

    private fun openApp(c: Ctx): Res? {
        val m = OPEN1.find(c.s) ?: OPEN2.find(c.s) ?: return null
        val name = m.groupValues[1].trim().removeSuffix(" app").removeSuffix(" application").trim()
        if (name.isEmpty()) return null
        if (!name.contains(" ") && Regex("^[a-z0-9-]+\\.[a-z]{2,}(/.*)?$", IC).matches(name)) {
            c.svc.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://$name")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Res("Khol raha hoon: $name")
        }
        return launchByName(c.svc, name)
    }

    private fun fallbackApp(c: Ctx): Res? =
        if (c.words.size <= 3) launchByName(c.svc, c.s) else null

    private fun launchByName(svc: AssistantService, name: String): Res? {
        val q = (ALIAS[name.lowercase()] ?: name).lowercase()
        val pm = svc.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return null
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return null
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        svc.startActivity(launch)
        return Res("Khol raha hoon: " + match.loadLabel(pm))
    }

    private fun whatsapp(c: Ctx): Res? {
        val m = WA1.find(c.s) ?: WA2.find(c.s) ?: return null
        val who = m.groupValues[1].trim()
        val msg = m.groupValues[2].trim()
        if (who.isEmpty() || msg.isEmpty() || who.lowercase() in OPEN_WORDS) return null
        val num = waNumber(lookup(c.svc, who))
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=" + Uri.encode(msg)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.setPackage("com.whatsapp")
        try {
            c.svc.startActivity(i)
        } catch (e: Exception) {
            i.setPackage(null)
            c.svc.startActivity(i)
        }
        val sent = clickWhenVisible(c.svc, listOf("send", "bhejo"), 9)
        return Res(if (sent) "WhatsApp bhej diya: $who" else "WhatsApp khul gaya, Send khud dabao")
    }

    private fun sms(c: Ctx): Res? {
        val m = SMS1.find(c.s) ?: SMS2.find(c.s) ?: return null
        val who = m.groupValues[1].trim()
        val msg = m.groupValues[2].trim()
        if (who.isEmpty() || msg.isEmpty()) return null
        val num = lookup(c.svc, who)
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)))
            .putExtra("sms_body", msg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.svc.startActivity(i)
        val sent = clickWhenVisible(c.svc, listOf("send", "send sms", "send message", "bhejo"), 9)
        return Res(if (sent) "SMS bhej diya: $who" else "SMS khul gaya, Send khud dabao")
    }

    private fun typeClick(c: Ctx): Res? {
        if (c.t in setOf("send", "send karo", "send kar do", "send kro", "bhejo", "bhej do")) {
            val ok = clickWhenVisible(c.svc, listOf("send", "bhejo", "send message"), 2)
            return Res(if (ok) "Send dabaya" else "Send button nahi mila")
        }
        val tm = TYPE.find(c.s)
        if (tm != null) return typeText(c.svc, tm.groupValues[1])
        val m = CLICK1.find(c.s) ?: CLICK2.find(c.s) ?: return null
        return clickLabel(c.svc, m.groupValues[1].trim())
    }

    private fun search(c: Ctx): Res? {
        val yt = YT1.find(c.s) ?: YT2.find(c.s)
        if (yt != null) {
            val q = yt.groupValues[1].trim()
            openUrl(c.svc, "https://www.youtube.com/results?search_query=" + Uri.encode(q))
            return Res("YouTube pe search: $q")
        }
        val mp = MAPS1.find(c.s) ?: MAPS2.find(c.s)
        if (mp != null) {
            val q = mp.groupValues[1].trim()
            openUrl(c.svc, "geo:0,0?q=" + Uri.encode(q))
            return Res("Maps: $q")
        }
        val g = G1.find(c.s) ?: G2.find(c.s)
        if (g != null) {
            val q = g.groupValues[1].trim()
            openUrl(c.svc, "https://www.google.com/search?q=" + Uri.encode(q))
            return Res("Google search: $q")
        }
        return null
    }

    private fun photo(c: Ctx): Res? {
        if (!(c.hasText("photo", "selfie") || c.has("pic", "picture"))) return null
        if (!c.has("khicho", "kheecho", "khincho", "khichna", "click", "lo", "le", "take")) return null
        c.svc.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Res("Camera khol diya")
    }

    // ------------------------------------------------------------------ helpers

    private fun openUrl(svc: AssistantService, url: String) {
        svc.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun lookup(svc: AssistantService, name: String): String {
        val digits = name.replace(Regex("[\\s\\-()]"), "")
        if (digits.matches(Regex("\\+?\\d{5,}"))) return digits
        if (svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            throw IllegalStateException("Contacts permission do (app mein 'Permissions' button dabao)")
        }
        val cur = svc.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cur?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        throw IllegalStateException("Contact nahi mila: $name")
    }

    private fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("0")) d = d.trimStart('0')
        if (d.length == 10) d = "91$d"
        return d
    }

    fun allNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (out.size > 400) return
            if (n.isVisibleToUser) out.add(n)
            for (i in 0 until n.childCount) {
                val ch = n.getChild(i) ?: continue
                walk(ch)
            }
        }
        walk(root)
        return out
    }

    private fun labels(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).map { it.lowercase().trim() }

    private fun clickLabel(svc: AssistantService, label: String): Res {
        val root = svc.rootInActiveWindow ?: return Res("Screen nahi padh paya")
        val q = label.lowercase()
        val nodes = allNodes(root)
        val node = nodes.firstOrNull { n -> labels(n).any { l -> l == q } }
            ?: nodes.firstOrNull { n -> labels(n).any { l -> l.contains(q) } }
            ?: return Res("'$label' screen pe nahi mila")
        return Res(if (clickNode(svc, node)) "Click kiya: $label" else "Click nahi ho paya: $label")
    }

    private fun clickWhenVisible(svc: AssistantService, names: List<String>, tries: Int): Boolean {
        for (k in 0 until tries) {
            Thread.sleep(700)
            val root = svc.rootInActiveWindow ?: continue
            val node = allNodes(root).firstOrNull { n -> labels(n).any { l -> l in names } }
            if (node != null && clickNode(svc, node)) return true
        }
        return false
    }

    private fun typeText(svc: AssistantService, text: String): Res {
        val root = svc.rootInActiveWindow ?: return Res("Screen nahi padh paya")
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: allNodes(root).firstOrNull { it.isEditable }
            ?: return Res("Koi text box nahi mila (pehle box pe tap karo)")
        val cur = if (node.isShowingHintText) "" else node.text?.toString() ?: ""
        val full = (if (cur.isEmpty()) "" else "$cur ") + text
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, full)
        return Res(if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "Likh diya: $text" else "Likh nahi paya")
    }

    fun clickNode(svc: AssistantService, n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return gestureTap(svc, r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun gestureTap(svc: AssistantService, x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return svc.dispatchGesture(g, null, null)
    }

    private fun swipe(svc: AssistantService, x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 400))
            .build()
        return svc.dispatchGesture(g, null, null)
    }
}
